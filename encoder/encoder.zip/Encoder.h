#include <Arduino.h>

class Encoder
{

private:

	int count;
	int pin_in;

public:
	Encoder(int pin_in);
	~Encoder();
	void countSteps();
	static void findInterruptions();
	int getSteps();
	void setSteps(int ammount);
};